// Definir dos silos: uno para soja y otro para maíz.
//Cada silo tendrá una capacidad
// máxima y un stock actual de cereal.


// Implementar una función Solicitar al usuario el tipo de cereal 
// (soja o maíz) y el peso de la carga.
function ingresarCamion(){
    let salida;
    let siloSoja = {stockActual: 0, capacidadMaxima: 3000};
    let siloMaiz = {stockActual: 0, capacidadMaxima: 4500};
    do {
    let solicitarTipoCereal = prompt('Ingresá el tipo de cereal(soja/maiz)')
    let pesoCarga = solicitarPeso()
    //Validar los datos ingresados (por ejemplo, que el peso sea un número positivo).
    if(pesoCarga <= 0){
        mostrarMensaje('Debe ingresar un número positivo, diferente de 0.')
        pesoCarga = solicitarPeso()
        // ver : mejora de salida.       
    }
    // Determinar el silo correspondiente al tipo de cereal.
    // Verificar si hay suficiente espacio en el silo para almacenar la carga.
    // Si hay espacio, actualizar el stock del silo y mostrar un mensaje informando
    // sobre el ingreso del camión.
    // o Si no hay espacio, mostrar un mensaje indicando que el silo está lleno.
    switch (solicitarTipoCereal?.toLocaleLowerCase()) {
        case 'soja':
            if (siloSoja.stockActual >= siloSoja.capacidadMaxima) {
                mostrarMensaje('No hay suficiente espacio en el silo para almacenar la carga.')
                salida = salir()
            } else {
                siloSoja.stockActual += pesoCarga
                mostrarMensaje('El cereal fue almacenado con éxito!')
            }
            break;
        case 'maiz':
            if (siloMaiz.stockActual >= siloMaiz.stockActual.capacidadMaxima) {
                mostrarMensaje('No hay suficiente espacio en el silo para almacenar la carga.')
                salida = salir()
            } else {
                siloMaiz.stockActual += pesoCarga
                mostrarMensaje('El cereal fue almacenado con éxito!')
            }
            break;
        default:
            mostrarMensaje('Error, Ingrese un tipo de cereal válido (soja/maiz)')
            salida = salir()
            break;
    }
} 
    while (salida != 1); 
    // Si salida es false es decir, salida = 1 != 1 , false, corta el while,
    // salida 2 != 1, true sigue el while..
}

function solicitarPeso(){
    let peso = parseFloat(prompt('Ingresá el peso de la carga'))
    return peso    
}
function mostrarMensaje(mensaje){
    alert(mensaje)
}

function salir(){
    let salir = prompt('¿Desea salir? escriba 1, de lo contrario para reintentar ingrese 2')
    if(salir == 1){
         mostrarMensaje('Muchas gracias por usar el servicio de AgroSilos, Vuelva pronto!😊')
         return salir
        } else {
            return salir
        }
}

ingresarCamion()





/*// Definición de los silos  
const silos = {  
    soja: {  
        capacidadMaxima: 10000, // Capacidad máxima del silo de soja  
        stockActual: 5000, // Stock actual del silo de soja  
    },  
    maiz: {  
        capacidadMaxima: 8000, // Capacidad máxima del silo de maíz  
        stockActual: 3000, // Stock actual del silo de maíz  
    }  
};  

// Función para ingresar un camión  
function ingresarCamion() {  
    let continuar;  // Variable para controlar el bucle  
    do {  
        // Solicitar el tipo de cereal  
        let tipoCereal = prompt("Ingrese el tipo de cereal (soja o maíz) o escriba 'salir' para terminar:").toLowerCase();  
        
        // Opción para salir  
        if (tipoCereal === 'salir') {  
            alert("Saliendo del programa.");  
            break;  // Sale de la función  
        }  
        
        // Solicitar el peso de la carga  
        let pesoCarga = parseFloat(prompt("Ingrese el peso de la carga (número positivo):"));  

        // Validar datos ingresados  
        if (!pesoCarga || pesoCarga <= 0) {  
            alert("Error: El peso debe ser un número positivo.");  
            continue;  // Regresa al inicio del bucle  
        }  

        // Determinar el silo correspondiente  
        let silo;  
        switch (tipoCereal) {  
            case "soja":  
                silo = silos.soja;  
                break;  
            case "maíz":  
                silo = silos.maiz;  
                break;  
            default:  
                alert("Error: Tipo de cereal no válido. Debe ser soja o maíz.");  
                continue;  // Regresa al inicio del bucle  
        }  

        // Verificar si hay suficiente espacio en el silo  
        if (silo.stockActual + pesoCarga <= silo.capacidadMaxima) {  
            // Actualizar el stock del silo  
            silo.stockActual += pesoCarga;  
            alert(`Ingreso exitoso. Se ha agregado ${pesoCarga} kg al silo de ${tipoCereal}. Stock actual: ${silo.stockActual} kg.`);  
        } else {  
            alert(`Error: El silo de ${tipoCereal} está lleno. No hay suficiente espacio.`);  
        }  

        // Preguntar si desea continuar o salir  
        continuar = prompt("¿Desea continuar ingresando? (sí para continuar, cualquier otra tecla para salir)").toLowerCase();  
        
    } while (continuar === 'sí');  // Continuar mientras la respuesta sea 'sí'  
}  

// Ejecución de la función para ingresar un camión  
ingresarCamion();*/